package mstrings;

public class ComparacaoIgualdadeString {
	public static void main(String[] args) {
		String string1 = "TI Expert";
		String string2 = "ti expert";
		System.out.println("S�o iguais? (case sensitive)");
		System.out.println(string1.equals(string2) ? "sim" : "n�o");
		System.out.println("S�o iguais? (sem case sensitive)");
		System.out.println(string1.equalsIgnoreCase(string2) ? "sim" : "n�o");
	}
}