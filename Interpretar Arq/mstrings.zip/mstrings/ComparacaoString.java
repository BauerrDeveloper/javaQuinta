package mstrings;

public class ComparacaoString {

	public static void main(String[] args) {
		String string1 = "TI Expert";
		String string2 = "ti expert";
		int comparacao = string1.compareTo(string2);
		System.out.println("Compara��o entre string1 e string2 (sensitive case)");
		if (comparacao > 0) {
			System.out.println("string1 � lexicograficamente maior que string2");
		} else if (comparacao < 0) {
			System.out.println("string1 � lexicograficamente menor que string2");
		} else {
			System.out.println("string1 � lexicograficamente igual a string2");
		}
	}
}
