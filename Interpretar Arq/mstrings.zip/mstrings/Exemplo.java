package mstrings;

public class Exemplo {
	public static void main(String[] args) {
		String string1 = "15:30:00";
		String[] stringDividida = string1.split(":");
		for (int i = 0; i < stringDividida.length; i++) {
			System.out.println("stringDividida[" + i + "]=" + stringDividida[i]);
		}
	}
}