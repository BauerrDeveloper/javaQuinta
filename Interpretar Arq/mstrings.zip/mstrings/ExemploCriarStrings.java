package mstrings;

public class ExemploCriarStrings {
	public static void main(String[] args) {
		char[] charArray = { 'T', 'I', ' ', 'E', 'x', 'p', 'e', 'r', 't' };
		/* construindo uma string a partir de um array de char */
		String string1 = new String(charArray);
		/* construindo uma string a partir de uma string literal */
		String string2 = "www.tiexpert.net";
		System.out.println(string1);
		System.out.println(string2);
	}
}
