package mstrings;

public class ExemploSubstring {
	public static void main(String[] args) {
		String url = "www.tiexpert.net";
		String dominio = url.substring(4);
		String site = url.substring(url.indexOf('.') + 1, url.lastIndexOf('.'));
		System.out.println("An�lise da string:");
		System.out.println("Dom�nio: " + dominio);
		System.out.println("Site: " + site);
	}
}
