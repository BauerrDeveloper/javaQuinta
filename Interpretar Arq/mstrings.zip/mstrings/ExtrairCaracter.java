package mstrings;

public class ExtrairCaracter {
	 public static void main(String[] args) {
	 String string1 = "TI Expert";
	 char caracter = string1.charAt(3);
	 System.out.println("O 4o. caracter desta string � " + caracter);
	 }
	}
