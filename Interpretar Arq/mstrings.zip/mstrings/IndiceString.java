package mstrings;

public class IndiceString {
	public static void main(String[] args) {
		String string1 = "www.tiexpert.net";
		int posicao;
		posicao = string1.indexOf("tiexpert");
		if (posicao >= 0) {
			System.out.println("A string tiexpert come�a na posi��o " + posicao);
		} else {
			System.out.println("N�o h� tiexpert na string");
		}
		posicao = string1.lastIndexOf(".com");
		if (posicao >= 0) {
			System.out.println("A string .com come�a na posi��o " + posicao);
		} else {
			System.out.println("N�o h� .com na string");
		}
	}
}
