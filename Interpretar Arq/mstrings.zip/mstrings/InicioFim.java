package mstrings;

public class InicioFim {
	public static void main(String[] args) {
		String string1 = "http://www.tiexpert.net";
		System.out.println("A string " + string1 + " �:");
		// verifica se h� 'http:' no inicio da string
		if (string1.startsWith("http:")) {
			System.out.println("uma URL");
		}
		/*
		 * verifica se h� 'www' no in�cio da string, mas apenas a partir do 8o.
		 * caracter, ou seja, ap�s o prefixo 'http://', portanto dever� ser compensado 7
		 * caracteres
		 */
		if (string1.startsWith("www", 7)) {
			System.out.println("uma p�gina da web");
		}
		if (string1.endsWith(".br")) {
			System.out.println("um site registrado no Brasil");
		} else {
			System.out.println("n�o � um site registrado no Brasil");
		}
	}
}
