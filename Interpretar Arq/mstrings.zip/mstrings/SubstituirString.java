package mstrings;

public class SubstituirString {
	public static void main(String[] args) {
		String string1 = "http://tiexpert.net";
		System.out.println(string1.replace("http://", "www."));
	}
}
