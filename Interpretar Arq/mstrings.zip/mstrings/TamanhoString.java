package mstrings;

public class TamanhoString {
	public static void main(String[] args) {
		String str = "TI Expert";
		System.out.println(str + " possui " + str.length() + " caracteres.");
	}
}