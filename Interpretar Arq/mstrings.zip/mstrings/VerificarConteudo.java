package mstrings;

public class VerificarConteudo {
	public static void main(String[] args) {
		String string1 = "http://www.tiexpert.net";
		System.out.println("� uma p�gina da web?");
		System.out.println(string1.contains("www.") ? "sim" : "n�o");
	}
}